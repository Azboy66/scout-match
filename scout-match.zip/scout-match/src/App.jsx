import { useState, useMemo, useEffect, useCallback } from "react";

// ── Config Championnats (IDs API-Football saison 2024) ────────────────────────
const LEAGUES_CONFIG = [
  { id: 61,  name: "Ligue 1",        country: "France",    flag: "🇫🇷", season: 2024 },
  { id: 39,  name: "Premier League", country: "Angleterre",flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", season: 2024 },
  { id: 140, name: "La Liga",        country: "Espagne",   flag: "🇪🇸", season: 2024 },
  { id: 135, name: "Serie A",        country: "Italie",    flag: "🇮🇹", season: 2024 },
  { id: 78,  name: "Bundesliga",     country: "Allemagne", flag: "🇩🇪", season: 2024 },
];

// ── Appels API-Football ───────────────────────────────────────────────────────
const API_BASE = "https://v3.football.api-sports.io";

async function apiFetch(endpoint, apiKey) {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { "x-apisports-key": apiKey },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.errors && Object.keys(data.errors).length > 0) {
    throw new Error(JSON.stringify(data.errors));
  }
  return data.response;
}

// Classement d'un championnat
async function fetchStandings(leagueId, season, apiKey) {
  const data = await apiFetch(`/standings?league=${leagueId}&season=${season}`, apiKey);
  if (!data || !data[0]) return [];
  const standings = data[0].league.standings[0];
  return standings.map(s => ({
    team: s.team.name,
    teamId: s.team.id,
    pos: s.rank,
    pts: s.points,
    gf: s.all.goals.for,
    ga: s.all.goals.against,
  }));
}

// Matchs à venir (7 prochains jours)
async function fetchFixtures(leagueId, season, apiKey) {
  const today = new Date();
  const next7 = new Date(today);
  next7.setDate(today.getDate() + 7);
  const fmt = d => d.toISOString().split("T")[0];
  const data = await apiFetch(
    `/fixtures?league=${leagueId}&season=${season}&from=${fmt(today)}&to=${fmt(next7)}&status=NS`,
    apiKey
  );
  return (data || []).map(f => ({
    id: f.fixture.id,
    leagueId,
    home: f.teams.home.name,
    away: f.teams.away.name,
    date: new Date(f.fixture.date).toLocaleDateString("fr-FR"),
    time: new Date(f.fixture.date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
  }));
}

// ── Analyse des matchs ────────────────────────────────────────────────────────
function analyzeMatch(match, standingsMap) {
  const standings = standingsMap[match.leagueId] || [];
  const home = standings.find(t => t.team === match.home);
  const away = standings.find(t => t.team === match.away);
  if (!home || !away) return null;

  const total = standings.length;
  const ptsDiff = Math.abs(home.pts - away.pts);
  const flags = [];

  const titleRace = home.pos <= 3 && away.pos <= 3;
  const euroRace = (home.pos >= 4 && home.pos <= 7) || (away.pos >= 4 && away.pos <= 7);
  const relegationBattle = home.pos >= total - 3 || away.pos >= total - 3;
  const tightDuel = ptsDiff <= 2;

  if (titleRace)              flags.push({ label: "Titre",      color: "#f59e0b", icon: "🏆" });
  if (euroRace && !titleRace) flags.push({ label: "Europe",     color: "#3b82f6", icon: "⭐" });
  if (relegationBattle)       flags.push({ label: "Relégation", color: "#ef4444", icon: "⚠️" });
  if (tightDuel)              flags.push({ label: "Duel serré", color: "#10b981", icon: "⚡" });

  const score = flags.length * 2 + (home.pos <= 3 || away.pos <= 3 ? 1 : 0);
  return { home, away, flags, tightDuel, ptsDiff, score };
}

// ── Composants UI ─────────────────────────────────────────────────────────────
function Spinner() {
  return (
    <div style={{ display: "flex", justifyContent: "center", padding: "40px" }}>
      <div style={{
        width: 36, height: 36, borderRadius: "50%",
        border: "3px solid #1e293b",
        borderTop: "3px solid #f59e0b",
        animation: "spin 0.8s linear infinite",
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function Stat({ label, sub, highlight }) {
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ fontSize: "13px", fontWeight: 700, color: highlight ? "#f59e0b" : "#cbd5e1" }}>{label}</div>
      <div style={{ fontSize: "9px", color: "#475569", textTransform: "uppercase", letterSpacing: "0.05em" }}>{sub}</div>
    </div>
  );
}

function TeamBlock({ team, side }) {
  const isHome = side === "home";
  return (
    <div style={{ flex: 1, textAlign: isHome ? "left" : "right" }}>
      <div style={{ fontSize: "15px", fontWeight: 800, color: "#f1f5f9" }}>{team.team}</div>
      <div style={{ display: "flex", gap: "8px", marginTop: "4px", justifyContent: isHome ? "flex-start" : "flex-end" }}>
        <Stat label={`${team.pos}e`} sub="rang" />
        <Stat label={`${team.pts}`} sub="pts" highlight />
        <Stat label={`${team.gf}/${team.ga}`} sub="B±" />
      </div>
    </div>
  );
}

function MatchCard({ match, analysis, league }) {
  const { home, away, flags, tightDuel, ptsDiff } = analysis;
  const intensity = flags.length >= 3 ? "high" : flags.length === 2 ? "medium" : "low";
  const borderColor = { high: "#f59e0b", medium: "#3b82f6", low: "#334155" }[intensity];
  const borderWidth = intensity === "low" ? "1px" : "2px";
  const bg = intensity === "high"
    ? "linear-gradient(135deg, #1a1a2e, #16213e)"
    : intensity === "medium"
    ? "linear-gradient(135deg, #0f172a, #1e293b)"
    : "#0f172a";

  return (
    <div style={{
      borderRadius: "12px", padding: "16px", marginBottom: "12px",
      border: `${borderWidth} solid ${borderColor}`,
      background: bg, transition: "transform 0.2s", cursor: "default",
    }}
      onMouseEnter={e => e.currentTarget.style.transform = "translateY(-2px)"}
      onMouseLeave={e => e.currentTarget.style.transform = "translateY(0)"}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px", flexWrap: "wrap", gap: "6px" }}>
        <span style={{ fontSize: "11px", color: "#64748b", fontWeight: 600, letterSpacing: "0.04em" }}>
          {league.flag} {league.name} · {match.date} {match.time}
        </span>
        <div style={{ display: "flex", gap: "5px", flexWrap: "wrap" }}>
          {flags.map((f, i) => (
            <span key={i} style={{
              fontSize: "10px", fontWeight: 700, padding: "2px 8px",
              borderRadius: "20px", background: f.color + "22", color: f.color,
              border: `1px solid ${f.color}55`
            }}>
              {f.icon} {f.label}
            </span>
          ))}
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <TeamBlock team={home} side="home" />
        <div style={{ textAlign: "center", flex: "0 0 50px" }}>
          <div style={{ fontSize: "13px", fontWeight: 800, color: "#94a3b8" }}>VS</div>
          {tightDuel && <div style={{ fontSize: "10px", color: "#10b981", marginTop: "2px" }}>Δ {ptsDiff} pt{ptsDiff > 1 ? "s" : ""}</div>}
        </div>
        <TeamBlock team={away} side="away" />
      </div>
    </div>
  );
}

function FilterToggle({ active, onToggle, label, color, icon }) {
  return (
    <button onClick={onToggle} style={{
      padding: "8px 14px", borderRadius: "8px", cursor: "pointer",
      border: `1.5px solid ${active ? color : "#334155"}`,
      background: active ? color + "22" : "transparent",
      color: active ? color : "#64748b",
      fontSize: "12px", fontWeight: 700, transition: "all 0.15s",
      display: "flex", alignItems: "center", gap: "5px"
    }}>
      {icon} {label}
    </button>
  );
}

// ── App principale ─────────────────────────────────────────────────────────────
export default function App() {
  const [apiKey, setApiKey]                   = useState("");
  const [apiKeyInput, setApiKeyInput]         = useState("");
  const [showApiPanel, setShowApiPanel]       = useState(true);
  const [selectedLeagues, setSelectedLeagues] = useState([61, 39, 140, 135, 78]);
  const [filterTitle, setFilterTitle]         = useState(true);
  const [filterEurope, setFilterEurope]       = useState(true);
  const [filterRelegation, setFilterRelegation] = useState(true);
  const [filterTight, setFilterTight]         = useState(true);
  const [standingsMap, setStandingsMap]       = useState({});
  const [fixturesMap, setFixturesMap]         = useState({});
  const [loading, setLoading]                 = useState(false);
  const [errors, setErrors]                   = useState({});
  const [loadedAt, setLoadedAt]               = useState(null);
  const [apiStatus, setApiStatus]             = useState(null); // null | "ok" | "error"

  // ── Chargement données via API ─────────────────────────────────────────────
  const loadData = useCallback(async (key, leagueIds) => {
    if (!key) return;
    setLoading(true);
    setErrors({});
    setApiStatus(null);

    const newStandings = { ...standingsMap };
    const newFixtures  = { ...fixturesMap };
    const newErrors    = {};
    let anyOk = false;

    await Promise.all(leagueIds.map(async (lid) => {
      const league = LEAGUES_CONFIG.find(l => l.id === lid);
      if (!league) return;
      try {
        const [standings, fixtures] = await Promise.all([
          fetchStandings(lid, league.season, key),
          fetchFixtures(lid, league.season, key),
        ]);
        newStandings[lid] = standings;
        newFixtures[lid]  = fixtures;
        anyOk = true;
      } catch (err) {
        newErrors[lid] = err.message;
      }
    }));

    setStandingsMap(newStandings);
    setFixturesMap(newFixtures);
    setErrors(newErrors);
    setLoading(false);
    setLoadedAt(new Date());
    setApiStatus(anyOk ? "ok" : "error");
  }, []);

  const handleConnect = () => {
    const key = apiKeyInput.trim();
    if (!key) return;
    setApiKey(key);
    setShowApiPanel(false);
    loadData(key, selectedLeagues);
  };

  const handleRefresh = () => {
    if (apiKey) loadData(apiKey, selectedLeagues);
  };

  // Recharge quand on active un nouveau championnat avec une clé déjà saisie
  useEffect(() => {
    if (!apiKey) return;
    const missing = selectedLeagues.filter(id => !standingsMap[id] && !fixturesMap[id]);
    if (missing.length > 0) loadData(apiKey, missing);
  }, [selectedLeagues, apiKey]);

  // ── Construction des matchs analysés ───────────────────────────────────────
  const allFixtures = useMemo(() => {
    return Object.entries(fixturesMap).flatMap(([lid, fixtures]) =>
      fixtures.map(f => ({ ...f, leagueId: parseInt(lid) }))
    );
  }, [fixturesMap]);

  const analyzedMatches = useMemo(() => {
    const sourceFixtures = apiKey
      ? allFixtures.filter(f => selectedLeagues.includes(f.leagueId))
      : DEMO_FIXTURES.filter(f => selectedLeagues.includes(f.leagueId));
    const sourceStandings = apiKey ? standingsMap : DEMO_STANDINGS;

    return sourceFixtures
      .map(match => {
        const analysis = analyzeMatch(match, sourceStandings);
        if (!analysis || analysis.flags.length === 0) return null;
        const hasTitle     = analysis.flags.some(f => f.label === "Titre");
        const hasEurope    = analysis.flags.some(f => f.label === "Europe");
        const hasRelegation= analysis.flags.some(f => f.label === "Relégation");
        const hasTight     = analysis.flags.some(f => f.label === "Duel serré");
        const pass = (filterTitle && hasTitle) || (filterEurope && hasEurope)
                  || (filterRelegation && hasRelegation) || (filterTight && hasTight);
        if (!pass) return null;
        const league = LEAGUES_CONFIG.find(l => l.id === match.leagueId);
        return { match, analysis, league };
      })
      .filter(Boolean)
      .sort((a, b) => b.analysis.score - a.analysis.score);
  }, [allFixtures, standingsMap, selectedLeagues, apiKey, filterTitle, filterEurope, filterRelegation, filterTight]);

  const toggleLeague = id => setSelectedLeagues(prev =>
    prev.includes(id) ? prev.filter(l => l !== id) : [...prev, id]
  );

  const isDemo = !apiKey;

  return (
    <div style={{ minHeight: "100vh", background: "#060e1d", color: "#f1f5f9", fontFamily: "'Segoe UI', system-ui, sans-serif", padding: "24px 16px" }}>
      <div style={{ maxWidth: "740px", margin: "0 auto" }}>

        {/* ── Header ── */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
          <div>
            <h1 style={{
              fontSize: "26px", fontWeight: 900, margin: 0,
              background: "linear-gradient(135deg, #f59e0b, #ef4444)",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent"
            }}>⚽ Scout Match</h1>
            <p style={{ color: "#475569", fontSize: "13px", marginTop: "4px" }}>
              Sélecteur de matchs à enjeux · Paris sportifs
            </p>
          </div>
          <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
            {apiKey && loadedAt && (
              <button onClick={handleRefresh} title="Rafraîchir" style={{
                padding: "8px 10px", borderRadius: "8px",
                background: "#1e293b", border: "1px solid #334155",
                color: "#94a3b8", fontSize: "13px", cursor: "pointer"
              }}>🔄</button>
            )}
            <button onClick={() => setShowApiPanel(!showApiPanel)} style={{
              padding: "8px 12px", borderRadius: "8px",
              background: apiStatus === "ok" ? "#10b98122" : apiStatus === "error" ? "#ef444422" : "#1e293b",
              border: `1px solid ${apiStatus === "ok" ? "#10b981" : apiStatus === "error" ? "#ef4444" : "#334155"}`,
              color: apiStatus === "ok" ? "#10b981" : apiStatus === "error" ? "#ef4444" : "#94a3b8",
              fontSize: "12px", cursor: "pointer"
            }}>
              {apiStatus === "ok" ? "✅ API connectée" : apiStatus === "error" ? "❌ Erreur API" : "🔑 Connecter l'API"}
            </button>
          </div>
        </div>

        {/* ── Panneau API ── */}
        {showApiPanel && (
          <div style={{
            marginBottom: "20px", padding: "16px", borderRadius: "12px",
            background: "#0f172a", border: "1px solid #1e40af"
          }}>
            <p style={{ fontSize: "13px", color: "#60a5fa", margin: "0 0 4px", fontWeight: 700 }}>
              🔑 Connexion API-Football
            </p>
            <p style={{ fontSize: "12px", color: "#64748b", margin: "0 0 12px" }}>
              Crée un compte gratuit sur <a href="https://www.api-football.com" target="_blank" style={{ color: "#3b82f6" }}>api-football.com</a> (100 appels/jour gratuits) et colle ta clé ci-dessous.
            </p>
            <div style={{ display: "flex", gap: "8px" }}>
              <input
                value={apiKeyInput}
                onChange={e => setApiKeyInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleConnect()}
                placeholder="Colle ta clé API ici..."
                type="password"
                style={{
                  flex: 1, padding: "9px 12px", borderRadius: "8px",
                  background: "#1e293b", border: "1px solid #334155",
                  color: "#f1f5f9", fontSize: "13px",
                }}
              />
              <button onClick={handleConnect} style={{
                padding: "9px 18px", borderRadius: "8px",
                background: "#f59e0b", border: "none",
                color: "#000", fontWeight: 800, fontSize: "13px", cursor: "pointer"
              }}>
                Charger
              </button>
            </div>
            {isDemo && (
              <p style={{ fontSize: "11px", color: "#334155", marginTop: "10px", margin: "10px 0 0" }}>
                ⚡ Sans clé, l'application fonctionne avec des données de démonstration.
              </p>
            )}
          </div>
        )}

        {/* ── Erreurs API par championnat ── */}
        {Object.keys(errors).length > 0 && (
          <div style={{ marginBottom: "14px", padding: "12px", borderRadius: "8px", background: "#ef444411", border: "1px solid #ef444433" }}>
            {Object.entries(errors).map(([lid, msg]) => {
              const l = LEAGUES_CONFIG.find(x => x.id === parseInt(lid));
              return <p key={lid} style={{ margin: "2px 0", fontSize: "12px", color: "#ef4444" }}>⚠️ {l?.name || lid} : {msg}</p>;
            })}
          </div>
        )}

        {/* ── Championnats ── */}
        <div style={{ marginBottom: "14px" }}>
          <p style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "8px" }}>Championnats</p>
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
            {LEAGUES_CONFIG.map(l => (
              <button key={l.id} onClick={() => toggleLeague(l.id)} style={{
                padding: "7px 13px", borderRadius: "8px", cursor: "pointer",
                border: `1.5px solid ${selectedLeagues.includes(l.id) ? "#6366f1" : "#1e293b"}`,
                background: selectedLeagues.includes(l.id) ? "#6366f122" : "#0f172a",
                color: selectedLeagues.includes(l.id) ? "#a5b4fc" : "#475569",
                fontSize: "12px", fontWeight: 600, transition: "all 0.15s",
                display: "flex", alignItems: "center", gap: "5px"
              }}>
                {l.flag} {l.name}
                {loading && selectedLeagues.includes(l.id) && !standingsMap[l.id] && (
                  <span style={{ fontSize: "10px", color: "#f59e0b" }}>⏳</span>
                )}
                {standingsMap[l.id] && <span style={{ fontSize: "10px", color: "#10b981" }}>●</span>}
              </button>
            ))}
          </div>
        </div>

        {/* ── Critères ── */}
        <div style={{ marginBottom: "22px" }}>
          <p style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "8px" }}>Critères de sélection</p>
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
            <FilterToggle active={filterTitle}      onToggle={() => setFilterTitle(!filterTitle)}           label="Course au titre"       color="#f59e0b" icon="🏆" />
            <FilterToggle active={filterEurope}     onToggle={() => setFilterEurope(!filterEurope)}         label="Qualification Europe"  color="#3b82f6" icon="⭐" />
            <FilterToggle active={filterRelegation} onToggle={() => setFilterRelegation(!filterRelegation)} label="Lutte relégation"      color="#ef4444" icon="⚠️" />
            <FilterToggle active={filterTight}      onToggle={() => setFilterTight(!filterTight)}           label="Duel serré (≤ 2 pts)"  color="#10b981" icon="⚡" />
          </div>
        </div>

        {/* ── Résultats ── */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px" }}>
          <p style={{ margin: 0, fontSize: "13px", color: "#94a3b8" }}>
            <span style={{ color: "#f59e0b", fontWeight: 800, fontSize: "18px" }}>{analyzedMatches.length}</span>
            {" "}match{analyzedMatches.length !== 1 ? "s" : ""} sélectionné{analyzedMatches.length !== 1 ? "s" : ""}
            {isDemo && <span style={{ fontSize: "11px", color: "#334155", marginLeft: "8px" }}>(démo)</span>}
          </p>
          {loadedAt && (
            <span style={{ fontSize: "11px", color: "#334155" }}>
              Mis à jour {loadedAt.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
            </span>
          )}
        </div>

        {loading ? <Spinner /> : analyzedMatches.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 20px", background: "#0f172a", borderRadius: "12px", border: "1px dashed #1e293b" }}>
            <div style={{ fontSize: "36px", marginBottom: "12px" }}>🔍</div>
            <p style={{ color: "#475569", fontSize: "14px" }}>
              Aucun match ne correspond aux critères actifs.<br />
              Active au moins un critère ou sélectionne un championnat.
            </p>
          </div>
        ) : (
          analyzedMatches.map(({ match, analysis, league }) => (
            <MatchCard key={match.id} match={match} analysis={analysis} league={league} />
          ))
        )}

        <p style={{ textAlign: "center", fontSize: "11px", color: "#1e293b", marginTop: "28px" }}>
          {isDemo ? "Mode démonstration · Connecte l'API pour les matchs réels" : "Données API-Football · Saison 2024"}
        </p>
      </div>
    </div>
  );
}

// ── Données de démonstration (fallback sans clé API) ──────────────────────────
const DEMO_STANDINGS = {
  61: [
    { team: "PSG",        pts: 78, pos: 1,  gf: 82, ga: 28 },
    { team: "Monaco",     pts: 72, pos: 2,  gf: 70, ga: 38 },
    { team: "Lens",       pts: 65, pos: 3,  gf: 58, ga: 42 },
    { team: "Lille",      pts: 64, pos: 4,  gf: 55, ga: 40 },
    { team: "Lyon",       pts: 58, pos: 5,  gf: 62, ga: 55 },
    { team: "Marseille",  pts: 57, pos: 6,  gf: 60, ga: 52 },
    { team: "Rennes",     pts: 56, pos: 7,  gf: 48, ga: 44 },
    { team: "Nice",       pts: 55, pos: 8,  gf: 47, ga: 43 },
    { team: "Strasbourg", pts: 38, pos: 9,  gf: 38, ga: 58 },
    { team: "Nantes",     pts: 37, pos: 10, gf: 35, ga: 60 },
    { team: "Brest",      pts: 36, pos: 11, gf: 33, ga: 62 },
    { team: "Toulouse",   pts: 35, pos: 12, gf: 31, ga: 65 },
    { team: "Angers",     pts: 28, pos: 13, gf: 28, ga: 70 },
    { team: "Montpellier",pts: 22, pos: 14, gf: 25, ga: 78 },
    { team: "Lorient",    pts: 18, pos: 15, gf: 20, ga: 85 },
    { team: "Metz",       pts: 15, pos: 16, gf: 18, ga: 88 },
    { team: "Clermont",   pts: 12, pos: 17, gf: 15, ga: 92 },
    { team: "Auxerre",    pts: 10, pos: 18, gf: 12, ga: 95 },
  ],
  39: [
    { team: "Manchester City", pts: 85, pos: 1,  gf: 90, ga: 30 },
    { team: "Arsenal",         pts: 83, pos: 2,  gf: 85, ga: 28 },
    { team: "Liverpool",       pts: 80, pos: 3,  gf: 88, ga: 35 },
    { team: "Aston Villa",     pts: 72, pos: 4,  gf: 72, ga: 48 },
    { team: "Tottenham",       pts: 66, pos: 5,  gf: 65, ga: 55 },
    { team: "Chelsea",         pts: 65, pos: 6,  gf: 63, ga: 53 },
    { team: "Newcastle",       pts: 64, pos: 7,  gf: 60, ga: 52 },
    { team: "Man United",      pts: 48, pos: 8,  gf: 42, ga: 58 },
    { team: "West Ham",        pts: 40, pos: 9,  gf: 38, ga: 62 },
    { team: "Everton",         pts: 32, pos: 10, gf: 30, ga: 70 },
    { team: "Brentford",       pts: 31, pos: 11, gf: 28, ga: 72 },
    { team: "Fulham",          pts: 30, pos: 12, gf: 25, ga: 73 },
    { team: "Burnley",         pts: 22, pos: 13, gf: 20, ga: 80 },
    { team: "Sheffield",       pts: 18, pos: 14, gf: 18, ga: 85 },
    { team: "Luton",           pts: 12, pos: 15, gf: 14, ga: 88 },
  ],
  140: [
    { team: "Real Madrid",     pts: 90, pos: 1,  gf: 92, ga: 25 },
    { team: "Barcelone",       pts: 85, pos: 2,  gf: 88, ga: 30 },
    { team: "Atlético",        pts: 78, pos: 3,  gf: 70, ga: 38 },
    { team: "Séville",         pts: 65, pos: 4,  gf: 60, ga: 48 },
    { team: "Real Sociedad",   pts: 64, pos: 5,  gf: 58, ga: 50 },
    { team: "Athletic Bilbao", pts: 63, pos: 6,  gf: 56, ga: 52 },
    { team: "Villarreal",      pts: 55, pos: 7,  gf: 48, ga: 55 },
    { team: "Valencia",        pts: 38, pos: 8,  gf: 35, ga: 65 },
    { team: "Getafe",          pts: 36, pos: 9,  gf: 30, ga: 68 },
    { team: "Cadix",           pts: 25, pos: 10, gf: 22, ga: 78 },
    { team: "Grenade",         pts: 18, pos: 11, gf: 18, ga: 85 },
    { team: "Almeria",         pts: 12, pos: 12, gf: 14, ga: 90 },
  ],
  135: [
    { team: "Inter Milan",  pts: 88, pos: 1,  gf: 85, ga: 22 },
    { team: "AC Milan",     pts: 80, pos: 2,  gf: 78, ga: 32 },
    { team: "Juventus",     pts: 75, pos: 3,  gf: 70, ga: 38 },
    { team: "Naples",       pts: 68, pos: 4,  gf: 65, ga: 45 },
    { team: "Lazio",        pts: 65, pos: 5,  gf: 60, ga: 48 },
    { team: "Roma",         pts: 64, pos: 6,  gf: 58, ga: 50 },
    { team: "Atalanta",     pts: 63, pos: 7,  gf: 72, ga: 55 },
    { team: "Fiorentina",   pts: 55, pos: 8,  gf: 48, ga: 52 },
    { team: "Torino",       pts: 42, pos: 9,  gf: 38, ga: 60 },
    { team: "Bologne",      pts: 35, pos: 10, gf: 32, ga: 65 },
    { team: "Vérone",       pts: 25, pos: 11, gf: 22, ga: 75 },
    { team: "Sassuolo",     pts: 18, pos: 12, gf: 18, ga: 82 },
    { team: "Empoli",       pts: 15, pos: 13, gf: 14, ga: 85 },
    { team: "Salernitana",  pts: 10, pos: 14, gf: 10, ga: 90 },
  ],
  78: [
    { team: "Bayer Leverkusen", pts: 90, pos: 1,  gf: 89, ga: 24 },
    { team: "Bayern Munich",    pts: 84, pos: 2,  gf: 94, ga: 45 },
    { team: "Stuttgart",        pts: 73, pos: 3,  gf: 78, ga: 39 },
    { team: "Leipzig",          pts: 65, pos: 4,  gf: 68, ga: 47 },
    { team: "Dortmund",         pts: 64, pos: 5,  gf: 62, ga: 53 },
    { team: "Francfort",        pts: 55, pos: 6,  gf: 52, ga: 50 },
    { team: "Hoffenheim",       pts: 45, pos: 7,  gf: 45, ga: 55 },
    { team: "Werder Brême",     pts: 38, pos: 8,  gf: 38, ga: 58 },
    { team: "Heidenheim",       pts: 36, pos: 9,  gf: 34, ga: 60 },
    { team: "Freiburg",         pts: 35, pos: 10, gf: 32, ga: 60 },
    { team: "Augsbourg",        pts: 30, pos: 11, gf: 28, ga: 64 },
    { team: "Wolfsburg",        pts: 28, pos: 12, gf: 25, ga: 65 },
    { team: "Bochum",           pts: 22, pos: 13, gf: 20, ga: 72 },
    { team: "Darmstadt",        pts: 18, pos: 14, gf: 16, ga: 78 },
    { team: "Mayence",          pts: 15, pos: 15, gf: 14, ga: 80 },
    { team: "Cologne",          pts: 12, pos: 16, gf: 12, ga: 84 },
    { team: "Union Berlin",     pts: 10, pos: 17, gf: 10, ga: 88 },
    { team: "Dusseldorf",       pts:  8, pos: 18, gf:  8, ga: 92 },
  ],
};

const DEMO_FIXTURES = [
  { id: 101, leagueId: 61,  home: "Monaco",            away: "Lens",            date: "28/06/2026", time: "17:00" },
  { id: 102, leagueId: 61,  home: "Lille",             away: "Lyon",            date: "28/06/2026", time: "19:00" },
  { id: 103, leagueId: 61,  home: "Marseille",         away: "Rennes",          date: "29/06/2026", time: "15:00" },
  { id: 104, leagueId: 61,  home: "PSG",               away: "Monaco",          date: "30/06/2026", time: "21:00" },
  { id: 105, leagueId: 61,  home: "Lorient",           away: "Metz",            date: "30/06/2026", time: "15:00" },
  { id: 106, leagueId: 61,  home: "Clermont",          away: "Auxerre",         date: "01/07/2026", time: "19:00" },
  { id: 201, leagueId: 39,  home: "Arsenal",           away: "Liverpool",       date: "28/06/2026", time: "16:30" },
  { id: 202, leagueId: 39,  home: "Tottenham",         away: "Chelsea",         date: "28/06/2026", time: "14:00" },
  { id: 203, leagueId: 39,  home: "Burnley",           away: "Sheffield",       date: "29/06/2026", time: "14:00" },
  { id: 204, leagueId: 39,  home: "Luton",             away: "Everton",         date: "30/06/2026", time: "14:00" },
  { id: 301, leagueId: 140, home: "Barcelone",         away: "Atlético",        date: "28/06/2026", time: "21:00" },
  { id: 302, leagueId: 140, home: "Real Sociedad",     away: "Athletic Bilbao", date: "29/06/2026", time: "19:00" },
  { id: 303, leagueId: 140, home: "Cadix",             away: "Grenade",         date: "30/06/2026", time: "17:00" },
  { id: 401, leagueId: 135, home: "AC Milan",          away: "Juventus",        date: "28/06/2026", time: "20:45" },
  { id: 402, leagueId: 135, home: "Lazio",             away: "Roma",            date: "29/06/2026", time: "20:45" },
  { id: 403, leagueId: 135, home: "Sassuolo",          away: "Salernitana",     date: "30/06/2026", time: "18:00" },
  { id: 501, leagueId: 78,  home: "Bayer Leverkusen",  away: "Bayern Munich",   date: "28/06/2026", time: "18:30" },
  { id: 502, leagueId: 78,  home: "Stuttgart",         away: "Leipzig",         date: "29/06/2026", time: "15:30" },
  { id: 503, leagueId: 78,  home: "Heidenheim",        away: "Freiburg",        date: "30/06/2026", time: "15:30" },
  { id: 504, leagueId: 78,  home: "Darmstadt",         away: "Cologne",         date: "01/07/2026", time: "15:30" },
];
